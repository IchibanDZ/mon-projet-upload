import { promises as fs } from 'fs';
import path from 'path';
import { IncomingForm } from 'formidable';
import { getSession } from "next-auth/react";
import prisma from "../../lib/prisma";  // Utilisation de prisma depuis lib/prisma

export const config = {
  api: {
    bodyParser: false, // Désactive le bodyParser pour permettre à formidable de gérer la requête
  },
};

export default async function handler(req, res) {
  const session = await getSession({ req });
  if (!session) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  if (req.method === 'POST') {
    const form = new IncomingForm();
    form.uploadDir = path.join(process.cwd(), 'public/uploads');
    form.keepExtensions = true;

    form.parse(req, async (err, fields, files) => {
      if (err) {
        console.error("Error during file upload:", err);
        return res.status(500).json({ message: "Error during file upload." });
      }

      // Log pour vérifier le contenu de "files"
      console.log("Files received:", files);

      const file = files.file ? files.file[0] : null;
      if (!file) {
        return res.status(400).json({ message: "File not found" });
      }

      const fileName = file.originalFilename;
      if (!fileName) {
        return res.status(400).json({ message: "File name is missing" });
      }

      const relativeFilePath = `/uploads/${fileName}`;

      // Convertir jsonData en chaîne JSON si nécessaire
      const jsonData = typeof fields.jsonData === "string" ? fields.jsonData : JSON.stringify(fields.jsonData);
      if (!jsonData) {
        return res.status(400).json({ message: "JSON data is missing or invalid." });
      }

      const userId = parseInt(session.user.id, 10);

      try {
        const upload = await prisma.upload.create({
          data: {
            filePath: relativeFilePath,
            jsonData: jsonData,
            userId: userId,
          },
        });
        return res.status(200).json({ message: "File uploaded successfully!", upload });
      } catch (error) {
        console.error("Error during database save:", error);
        return res.status(500).json({ message: "Error during database save." });
      }
    });
  } else {
    return res.status(405).json({ message: "Method Not Allowed" });
  }
}
