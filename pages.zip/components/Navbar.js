"use client";
import Link from "next/link";
import { useSession, signOut } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function Navbar() {
  const { data: session, status } = useSession();
  const router = useRouter();

  const handleLogout = async () => {
    await signOut({ redirect: false });
    router.push("/auth/signin");
  };

  return (
    <nav className="bg-gray-800 text-white p-4 flex justify-between items-center">
      <div>
        <Link href="/" className="mr-4 hover:underline">
          Accueil
        </Link>
        <Link href="/myuploads" className="mr-4 hover:underline">
          Mes fichiers
        </Link>
        {status === "authenticated" && session?.user?.role === "ADMIN" && (
          <Link href="/admin" className="mr-4 hover:underline">
            Admin
          </Link>
        )}
        <Link href="/" className="mr-4 hover:underline">
          Upload
        </Link>
      </div>
      <div>
        {status === "authenticated" ? (
          <button
            onClick={handleLogout}
            className="bg-red-500 px-3 py-1 rounded hover:bg-red-600"
          >
            Se déconnecter
          </button>
        ) : (
          <Link
            href="/auth/signin"
            className="bg-blue-500 px-3 py-1 rounded hover:bg-blue-600"
          >
            Se connecter
          </Link>
        )}
      </div>
    </nav>
  );
}
